import test from 'node:test';import assert from 'node:assert/strict';import {mkdtemp,readFile,rm} from 'node:fs/promises';import {tmpdir} from 'node:os';import path from 'node:path';import {randomUUID} from 'node:crypto';
const directory=await mkdtemp(path.join(tmpdir(),'club-form-test-'));process.env.COOPERATION_DATA_DIR=directory;
const {handler}=await import('./cooperation.mjs');
const event={httpMethod:'POST',headers:{origin:'https://suanli-fc.com','content-type':'application/json','x-real-ip':'test'},body:JSON.stringify({company:'TEST Company',contact:'TEST Contact',email:'test@example.invalid',intent:'other',requestId:randomUUID()})};
test('persists once and acknowledges only after writing; rejects invalid and cross-origin submissions',async()=>{try{
 const first=await handler(event);assert.equal(first.statusCode,201);assert.ok(JSON.parse(first.body).id);
 const repeated=await handler(event);assert.equal(repeated.statusCode,200);assert.equal(repeated.body,first.body);
 assert.equal((await handler({...event,body:'{}'})).statusCode,400);
 assert.equal((await handler({...event,headers:{...event.headers,origin:'https://unrelated.example'}})).statusCode,403);
 assert.equal((await handler({...event,body:'x'.repeat(8193)})).statusCode,413);
 assert.equal((await handler({...event,httpMethod:'GET'})).statusCode,405);
 const rows=(await readFile(path.join(directory,'requests.jsonl'),'utf8')).trim().split('\n');assert.equal(rows.length,1);assert.equal(JSON.parse(rows[0]).email,'test@example.invalid');
 }finally{await rm(directory,{recursive:true,force:true})}});
