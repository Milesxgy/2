import http from 'node:http';
import {handler as getNewsHandler} from './netlify/functions/getNews.js';

const port = Number(process.env.PORT || 8080);
const routes = new Map([
  ['/.netlify/functions/getNews', getNewsHandler],
  ['/getNews', getNewsHandler],
]);

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];

    req.on('data', (chunk) => chunks.push(chunk));
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    req.on('error', reject);
  });
}

function normalizeHeaders(headers) {
  return Object.fromEntries(
    Object.entries(headers).map(([key, value]) => [
      key,
      Array.isArray(value) ? value.join(',') : value ?? '',
    ]),
  );
}

const server = http.createServer(async (req, res) => {
  const origin = `http://${req.headers.host || 'localhost'}`;
  const url = new URL(req.url || '/', origin);

  if (url.pathname === '/healthz') {
    res.writeHead(200, {'Content-Type': 'text/plain; charset=utf-8'});
    res.end('ok');
    return;
  }

  const routeHandler = routes.get(url.pathname);
  if (!routeHandler) {
    res.writeHead(404, {'Content-Type': 'application/json; charset=utf-8'});
    res.end(JSON.stringify({success: false, message: 'Not found'}));
    return;
  }

  try {
    const body = await readBody(req);
    const result = await routeHandler(
      {
        httpMethod: req.method || 'GET',
        path: url.pathname,
        rawUrl: url.toString(),
        rawQuery: url.searchParams.toString(),
        headers: normalizeHeaders(req.headers),
        queryStringParameters: Object.fromEntries(url.searchParams.entries()),
        body: body || undefined,
        isBase64Encoded: false,
      },
      {},
    );

    const statusCode = Number(result?.statusCode) || 200;
    const headers = {
      'Content-Type': 'application/json; charset=utf-8',
      ...(result?.headers || {}),
    };

    res.writeHead(statusCode, headers);
    res.end(result?.body || '');
  } catch (error) {
    console.error('Function API error:', error);
    res.writeHead(500, {'Content-Type': 'application/json; charset=utf-8'});
    res.end(JSON.stringify({success: false, message: 'Internal server error'}));
  }
});

server.listen(port, '0.0.0.0', () => {
  console.log(`Function API listening on ${port}`);
});
