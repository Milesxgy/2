import {mkdir,readFile,open} from 'node:fs/promises';
import path from 'node:path';
import {randomUUID} from 'node:crypto';
const directory=process.env.COOPERATION_DATA_DIR||'/srv/cooperation-data';
const file=path.join(directory,'requests.jsonl');
const origins=new Set(['https://suanli-fc.com','https://www.suanli-fc.com','http://suanli-fc.com','http://www.suanli-fc.com','https://suanli-fc.soundcouch.chatgpt.site','https://2-two-omega.vercel.app','https://suanli-fc.vercel.app',...(process.env.COOPERATION_EXTRA_ORIGINS||'').split(',').filter(Boolean)]);
const requests=new Map(),rate=new Map();let queue=Promise.resolve();
let ready;
async function initialize(){
 await mkdir(directory,{recursive:true,mode:0o700});
 try{for(const line of (await readFile(file,'utf8')).trim().split('\n')){try{const row=JSON.parse(line);requests.set(row.requestId,row)}catch{}}}catch(e){if(e.code!=='ENOENT')throw e}
}
function reply(statusCode,payload,origin){return {statusCode,headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','Vary':'Origin',...(origins.has(origin)?{'Access-Control-Allow-Origin':origin,'Access-Control-Allow-Methods':'POST, OPTIONS','Access-Control-Allow-Headers':'Content-Type'}:{})},body:JSON.stringify(payload)}}
export async function handler(event){
 const headers=event.headers||{};const origin=headers.origin||headers.Origin||'';
 if(!origins.has(origin))return reply(403,{success:false},origin);
 if(event.httpMethod==='OPTIONS')return reply(204,{},origin);
 if(event.httpMethod!=='POST')return reply(405,{success:false},origin);
 if(!/^application\/json(?:;|$)/i.test(headers['content-type']||''))return reply(415,{success:false},origin);
 if(Buffer.byteLength(event.body||'')>8192)return reply(413,{success:false},origin);
 let fields;try{fields=JSON.parse(event.body||'')}catch{return reply(400,{success:false},origin)}
 if(!fields||typeof fields!=='object')return reply(400,{success:false},origin);
 if(fields.website)return reply(400,{success:false},origin);
 const company=typeof fields.company==='string'?fields.company.trim():'';
 const contact=typeof fields.contact==='string'?fields.contact.trim():'';
 const email=typeof fields.email==='string'?fields.email.trim():'';
 const intent=fields.intent,requestId=fields.requestId;
 if(!company||company.length>120||!contact||contact.length>80||email.length>254||!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)||!['marketing','friendlies','academy','other'].includes(intent)||typeof requestId!=='string'||!/^[0-9a-f-]{36}$/i.test(requestId)||/[\u0000-\u001f]/.test(company+contact+email))return reply(400,{success:false},origin);
 try{
  ready ||= initialize();await ready;
  const result=queue.then(async()=>{
   const duplicate=requests.get(requestId);if(duplicate)return reply(200,{success:true,id:duplicate.id},origin);
   const now=Date.now(),ip=headers['x-real-ip']||'unknown';
   for(const [key,item] of rate)if(now-item.start>600000)rate.delete(key);
   const limit=rate.get(ip)||{start:now,count:0};if(limit.count>=10)return reply(429,{success:false},origin);
   limit.count++;rate.set(ip,limit);
   const row={id:randomUUID(),requestId,createdAt:new Date().toISOString(),company,contact,email,intent};
   const handle=await open(file,'a',0o600);try{await handle.writeFile(JSON.stringify(row)+'\n');await handle.sync()}finally{await handle.close()}
   requests.set(requestId,row);return reply(201,{success:true,id:row.id},origin);
  });queue=result.catch(()=>{});return await result;
 }catch{return reply(503,{success:false},origin)}
}
