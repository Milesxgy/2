#!/bin/bash
set -euo pipefail
if docker compose version >/dev/null 2>&1; then club_compose=(docker compose); else club_compose=(docker-compose); fi
club_app=/home/web/docker/2-main
club_files=$(cd "$(dirname "$0")" && pwd)
club_backup=/home/web/suanli-site-backups/$(date -u +%Y%m%dT%H%M%SZ)-before-cooperation
install -d -m 700 "$club_backup" /home/web/suanli-private/cooperation
cp "$club_app/deploy/function-api/server.mjs" "$club_backup/server.mjs"
cp "$club_app/deploy/function-api/Dockerfile" "$club_backup/Dockerfile"
cp "$club_app/docker-compose.yaml" "$club_backup/docker-compose.yaml"
docker inspect --format '{{.Image}}' homework2-function-api-1 > "$club_backup/image-id.txt"
docker tag "$(cat "$club_backup/image-id.txt")" "suanli-function-api:backup-$(date -u +%Y%m%dT%H%M%SZ)"
cp "$club_files/server.mjs" "$club_app/deploy/function-api/server.mjs"
cp "$club_files/cooperation.mjs" "$club_app/deploy/function-api/cooperation.mjs"
cp "$club_files/Dockerfile" "$club_app/deploy/function-api/Dockerfile"
python3 - "$club_app/docker-compose.yaml" <<'PY'
import sys,pathlib
p=pathlib.Path(sys.argv[1]);s=p.read_text();old='    expose:\n      - "8080"\n'
assert s.count(old)==1
volume='      - /home/web/suanli-private/cooperation:/srv/cooperation-data\n'
if volume not in s:s=s.replace(old,old+'    volumes:\n'+volume)
p.write_text(s)
PY
cd "$club_app"
club_patch=$(mktemp -d /tmp/suanli-api-build.XXXXXXXX)
trap 'rm -rf -- "$club_patch"' EXIT
docker tag "$(cat "$club_backup/image-id.txt")" suanli-function-api-base:local
cp "$club_files/server.mjs" "$club_files/cooperation.mjs" "$club_patch/"
printf '%s\n' 'FROM suanli-function-api-base:local' 'WORKDIR /srv/app' 'COPY server.mjs cooperation.mjs ./' > "$club_patch/Dockerfile"
DOCKER_BUILDKIT=0 docker build --pull=false -t homework2-function-api "$club_patch"
"${club_compose[@]}" up -d --no-deps --no-build function-api
for attempt in $(seq 1 30); do
 if docker exec homework2-function-api-1 node -e "fetch('http://127.0.0.1:8080/healthz').then(r=>process.exit(r.ok?0:1)).catch(()=>process.exit(1))"; then break; fi
 sleep 1
done
docker exec homework2-nginx-1 nginx -t
docker exec homework2-nginx-1 nginx -s reload
printf 'COOPERATION_BACKUP=%s\n' "$club_backup"
