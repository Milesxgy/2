'use strict';
window.I18N=(()=>{
 const dictionary=window.SUANLI_EN||{},names=window.SUANLI_NAMES||{},texts=new WeakMap(),attributes=new WeakMap();
 const hasChinese=s=>/[\u3400-\u9fff]/.test(s),phrases=Object.keys(dictionary).filter(x=>x.length>1).sort((a,b)=>b.length-a.length);
 let saved;try{saved=localStorage.getItem('suanli-language')}catch{}
 const requested=new URL(location.href).searchParams.get('lang');
 let language=['zh','en'].includes(requested)?requested:['zh','en'].includes(saved)?saved:/^zh\b/i.test(navigator.language||'zh')?'zh':'en';
 function translate(source){
  if(dictionary[source]!==undefined)return dictionary[source];
  let m=source.match(/^(\d+(?:\s*\/\s*\d+)?)\s*(?:位球员|人)$/);if(m)return `${m[1]} players`;
  m=source.match(/^(共|找到) (\d+) 位球员 · 按报名姓名整理$/);if(m)return `${m[1]==='找到'?'Found':'All'} ${m[2]} players · By registration name`;
  if(!hasChinese(source))return source;
  let out=source;for(const phrase of phrases)if(out.includes(phrase))out=out.split(phrase).join(dictionary[phrase]);
  return out.replace(/，/g,', ').replace(/。/g,'.').replace(/；/g,'; ').replace(/：/g,': ').replace(/“|”/g,'"').replace(/《|》/g,'');
 }
 function convert(current,cache){
  if(!cache||current!==cache.zh&&current!==cache.en){const match=current.match(/^(\s*)([\s\S]*?)(\s*)$/);cache={zh:current,en:match[1]+translate(match[2])+match[3]}}
  return {cache,value:language==='en'?cache.en:cache.zh};
 }
 function apply(root=document){
  const base=root===document?document.documentElement:root;
  const walker=document.createTreeWalker(base,NodeFilter.SHOW_TEXT);const nodes=[];while(walker.nextNode())nodes.push(walker.currentNode);
  for(const node of nodes){if(node.parentElement?.closest('script,style,[data-no-translate]'))continue;const result=convert(node.nodeValue,texts.get(node));texts.set(node,result.cache);if(node.nodeValue!==result.value)node.nodeValue=result.value}
  const elements=[...(base.nodeType===1?[base]:[]),...base.querySelectorAll('*')];
  for(const el of elements){if(el.closest('[data-no-translate]'))continue;let cache=attributes.get(el)||{};for(const attr of ['aria-label','placeholder','alt','title',...(el.matches('meta[name="description"],meta[property="og:title"],meta[property="og:description"]')?['content']:[])]){if(!el.hasAttribute(attr))continue;const result=convert(el.getAttribute(attr),cache[attr]);cache[attr]=result.cache;if(el.getAttribute(attr)!==result.value)el.setAttribute(attr,result.value)}attributes.set(el,cache)}
  document.documentElement.lang=language==='en'?'en':'zh-CN';document.body.dataset.language=language;
  for(const button of document.querySelectorAll('[data-language-toggle]')){button.textContent=language==='en'?'中文':'EN';button.lang=language==='en'?'zh-CN':'en';const label=language==='en'?'切换为中文':'Switch to English';button.setAttribute('aria-label',label);button.title=label;button.setAttribute('data-current-language',language)}
 }
 function setLanguage(value){if(!['zh','en'].includes(value))return;language=value;try{localStorage.setItem('suanli-language',language)}catch{}const url=new URL(location.href);url.searchParams.set('lang',language);history.replaceState(history.state,'',url);for(const field of document.querySelectorAll('[data-share-url]')){try{const link=new URL(field.value);link.searchParams.set('lang',language);field.value=link.href}catch{}}apply();const status=document.getElementById('language-status');if(status)status.textContent=language==='en'?'English selected':'已切换为中文'}
 function matchesName(name,query){const q=query.trim().toLocaleLowerCase();const roman=(names[name]||name).toLocaleLowerCase();return name.toLocaleLowerCase().includes(q)||roman.includes(q)||roman.replace(/[\s·'-]/g,'').includes(q.replace(/[\s·'-]/g,''))}
 document.addEventListener('click',event=>{if(event.target.closest('[data-language-toggle]')){setLanguage(language==='en'?'zh':'en')}});
 return {apply,setLanguage,matchesName,translate,get language(){return language}};
})();
