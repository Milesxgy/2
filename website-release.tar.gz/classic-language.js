(()=>{
 let frame=0;
 const observer=new MutationObserver(()=>{if(!frame)frame=requestAnimationFrame(run)});
 function run(){frame=0;observer.disconnect();window.I18N?.apply();observer.observe(document.body,{childList:true,subtree:true,characterData:true})}
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',run);else run();
 document.addEventListener('click',()=>{if(!frame)frame=requestAnimationFrame(run)});
})();
